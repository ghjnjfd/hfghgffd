from ase import *
from gpaw import *
from numpy import *
from gpaw.mixer import Mixer, MixerSum
from ase import io

el1='B'
atoms = Atoms('%s' %el1,[(0,0,0)])
atoms.center(vacuum=8)
atoms.set_pbc(False)
l = atoms.get_cell().diagonal()
print 'original cell',l
l = 0.2*4*ceil(l/(4*0.2))
print 'new cell',l
atoms.set_cell(l)


for spin in [True]: #False,True]:
    mixer = Mixer(0.01,3)
    calc = GPAW(mode=PW(500),mixer=mixer,xc='PBE',occupations=FermiDirac(0.05),txt='%s_spin_%s.cal' %(el1,spin),spinpol=spin)
    atoms.set_calculator(calc)
    atoms.get_potential_energy()

    traj = io.Trajectory('%s_spin_%s.traj' %(el1,spin),'w',atoms)
    traj.write()

