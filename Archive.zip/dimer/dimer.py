from ase import *
from gpaw import *
from numpy import *
from gpaw.mixer import Mixer, MixerSum
from ase import io


el1,el2 = 'B','B'
Rref = 0.85*2
Rl = linspace(Rref*0.85,Rref+1.0,15)

atoms = Atoms('%s%s' %(el1,el2),[(0,0,0),(Rl[-1],0,0)])
atoms.center(vacuum=8)
atoms.set_pbc(False)
l = atoms.get_cell().diagonal()
print 'original cell',l
l = 0.2*4*ceil(l/(4*0.2))
print 'new cell',l
atoms.set_cell(l)


for spin in [False]:
    mixer = Mixer(0.01,3)
    calc = GPAW(h=0.2,mixer=mixer,xc='PBE',occupations=FermiDirac(0.05),txt='%s%s_dimer_spin_%s.cal' %(el1,el2,spin),spinpol=spin)
    atoms.set_calculator(calc)

    traj = io.Trajectory('%s%s_dimer_spin_%s.traj' %(el1,el2,spin),'w',atoms)
    for R in Rl:
        atoms[1].x = atoms[0].x + R
        atoms.get_potential_energy()
        traj.write()

