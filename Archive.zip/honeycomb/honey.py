from ase import Atoms
from gpaw import GPAW, PW
from numpy import sqrt, ones, linspace
from ase.parallel import rank
from ase.io import write
from ase.io.trajectory import Trajectory
from helper.quadopti import quadopti
from ase.visualize import view
from numpy import *

vac = 7
traj = Trajectory('trajectory.traj',mode = 'w')

nk = 12
calc = GPAW(mode=PW(500), xc = 'PBE', kpts = (nk,nk,1),spinpol = False)

a = 2.9
atoms = Atoms('B2',[(0,0,0),(a,a/sqrt(3),0)])
atoms.set_cell([(a,0,0),(a/2,a*sqrt(3)/2,0),(0,0,1)])
atoms.set_pbc((True,True,False))
atoms.center(vacuum=vac,axis=2)
atoms.set_calculator(calc)
cell0 = atoms.get_cell()

for x in linspace(0.9,1.4,20):
    cell = [x*cell0[0,:],x*cell0[1,:],cell0[2,:]]
    atoms.set_cell(cell,scale_atoms=True)    
    atoms.get_potential_energy()
    traj.write(atoms)

